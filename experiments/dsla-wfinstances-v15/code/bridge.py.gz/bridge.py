#!/usr/bin/env python3
"""Dedicated WfInstances v1.5 adapter for the PUBLIC repository's existing Benchmark workflow.

Only enabled when --algos=dsla_wfv15 is explicitly requested in a workflow_dispatch.
No production algorithms, workflow definitions, historical stores or author-frozen analysis
formulas are changed. All twenty input partitions and all original schedules are retained.
"""
from __future__ import annotations
import argparse
import base64
import csv
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import traceback

ROOT = Path(__file__).resolve().parents[3]
STUDY = ROOT / 'experiments' / 'dsla-wfinstances-v15'
WORK = ROOT / '.work'
FAMILIES = ('1000genome', 'cycles', 'seismology', 'soykb', 'srasearch')
STUDY_ID = 'dsla-wfinstances-v15-immutable-protocol-20261024'
SIGNAL = 'dsla_wfv15'
SHARDS_PER_FAMILY = 4
N_SHARDS = 20
SRC_SHA = '5be7070a3a0428e37babab2c7a932b455eb504c753ce4549c9bc47cccb448799'
ENGINE_SHA = '89e0badbd0577bbeabfb45fe1a923bcabb224718'
TRACE_TAG = 'v1.5'


def sha(x: bytes) -> str: return hashlib.sha256(x).hexdigest()

def check(args, **kw):
    return subprocess.run([str(x) for x in args], check=True, **kw)

def entry(i):
    if not 0 <= i < N_SHARDS: raise ValueError('Shard outside fixed 0..19 protocol: ' + str(i))
    return FAMILIES[i//SHARDS_PER_FAMILY], i % SHARDS_PER_FAMILY

def prepared_code():
    """Reconstruct only the SHA-verified public study sources, never use private checkouts."""
    files=[STUDY / f'source_bundle.part{x:02d}' for x in range(4)]
    if not all(p.is_file() for p in files):raise FileNotFoundError('Missing precommitted public source archive fragments')
    archive=b''.join(p.read_bytes() for p in files)
    expected=(STUDY/'SOURCE_BUNDLE_SHA256SUMS').read_text().split()[0]
    if sha(archive)!=expected:raise ValueError('Archive SHA-256 mismatch')
    for item in (STUDY/'SOURCE_PARTS_SHA256SUMS').read_text().splitlines():
        if not item.strip():continue
        h,relative=item.split(maxsplit=1)
        if sha((STUDY/relative).read_bytes())!=h:raise ValueError('Source fragment SHA mismatch '+relative)
    with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tf:
        for member in tf.getmembers():
            mp=Path(member.name)
            if mp.is_absolute() or '..' in mp.parts or member.issym() or member.islnk():
                raise ValueError('Unsafe source archive member')
        tf.extractall(STUDY, filter='data')
    for item in (STUDY/'SOURCE_SHA256SUMS').read_text().splitlines():
        if not item.strip():continue
        h,relative=item.split(maxsplit=1)
        if sha((STUDY/relative).read_bytes())!=h:raise ValueError('Source file SHA mismatch '+relative)
    return STUDY/'code'

def prep_plan(argv):
    ap=argparse.ArgumentParser(add_help=False)
    ap.add_argument('--algos');ap.add_argument('--shards');ap.add_argument('--github-output')
    a,_=ap.parse_known_args(argv)
    if a.algos!=SIGNAL:return False
    if str(a.shards) != '20':raise ValueError('Frozen public parallelism is 20 jobs; requested '+str(a.shards))
    matrix=[{'shard':i,'families':f'DSLAWFX_{entry(i)[0]}_{entry(i)[1]}'} for i in range(N_SHARDS)]
    payload={'study_id':STUDY_ID,'mode':SIGNAL,'n_shards':N_SHARDS,'matrix':matrix,'input_family_names':list(FAMILIES),'source_sha256':SRC_SHA}
    WORK.mkdir(exist_ok=True)
    (WORK/'plan.json').write_text(json.dumps(payload,indent=2)+'\n')
    with open(a.github_output,'a') as stream:
        stream.write('matrix='+json.dumps({'include':matrix},separators=(',',':'))+'\n')
        stream.write('todo='+str(N_SHARDS)+'\n')
    print('Fixed WfInstances v1.5 external study: exactly 5 families x 4 deterministic shards = 20 jobs')
    return True

def parse_token(s):
    if not s.startswith('DSLAWFX_'):return None
    v=s.split('_')
    if len(v)!=3:raise ValueError('Malformed fixed-family shard token')
    fam=v[1];local=int(v[2])
    if fam not in FAMILIES or not 0<=local<SHARDS_PER_FAMILY:raise ValueError('Nondeclared family or shard')
    return fam,local

def prep_fetch(argv):
    if '--families' not in argv:return False
    idx=argv.index('--families')
    if idx+1>=len(argv):return False
    pair=parse_token(argv[idx+1])
    if pair is None:return False
    fam,local=pair
    checkout=WORK/'wfinstances-v15'
    checkout.parent.mkdir(parents=True,exist_ok=True)
    if checkout.exists():shutil.rmtree(checkout)
    check(['git','clone','--depth','1','--filter=blob:none','--sparse','--branch',TRACE_TAG,'https://github.com/wfcommons/WfInstances.git',checkout])
    check(['git','-C',checkout,'sparse-checkout','set',f'pegasus/{fam}'])
    source=checkout/'pegasus'/fam
    files=sorted(source.glob('*.json'))
    if not files:raise ValueError('WfInstances v1.5 contained no JSON in '+str(source))
    target=WORK/'selected-wf'/ 'pegasus'/fam
    target.mkdir(parents=True,exist_ok=False)
    selected=[name for idx,name in enumerate(files) if idx%SHARDS_PER_FAMILY==local]
    for file in selected:shutil.copy2(file,target/file.name)
    manifest={'study_id':STUDY_ID,'family':fam,'local_shard':local,'source_tag':TRACE_TAG,
      'source_sha':subprocess.check_output(['git','-C',checkout,'rev-parse','HEAD'],text=True).strip(),
      'all_candidates':[x.name for x in files],
      'selected':[{'filename':x.name,'sha256':sha(x.read_bytes())} for x in selected]}
    (WORK/'selection.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
    print(f'Frozen WfInstances {fam}: shard {local}/4 has {len(selected)} of {len(files)} traces')
    return True

def empty_result(out:Path,fam:str):
    import sys
    out.mkdir()
    for name,content in [('source_manifest.json',[]),('failures.json',[])]:
        (out/name).write_text(json.dumps(content)+'\n')
    with gzip.open(out/'raw_schedules.jsonl.gz','wb'):pass
    fields=['family','file','p','bw_mib_s','source_sha256','n','e','d3_sha256','max_computation_cost','communication_nonzero_edges','sum_communication_cost','algo','makespan','timing_total_us_instrumented_engine','selected']
    with gzip.open(out/'results.csv.gz','wt',newline='') as fp:csv.DictWriter(fp,fieldnames=fields).writeheader()
    summary={'family':fam,'source_files_found':0,'eligible':0,'excluded':0,'cases':0,'schedule_records':0,'fatal_cases':0,'source_commit':'2f078d86b9d39835756f6ed9613279418a52371b','source_sha256':SRC_SHA}
    (out/'summary.json').write_text(json.dumps(summary)+'\n')

def run_study(argv):
    if not (WORK/'plan.json').is_file():return False
    plan=json.loads((WORK/'plan.json').read_text())
    if plan.get('study_id')!=STUDY_ID:return False
    ap=argparse.ArgumentParser(add_help=False)
    ap.add_argument('--shard',type=int,required=True);ap.add_argument('--out',required=True)
    a,_=ap.parse_known_args(argv)
    fam,local=entry(a.shard)
    selection=json.loads((WORK/'selection.json').read_text())
    if selection['family']!=fam or selection['local_shard']!=local:raise ValueError('Downloaded trace family/shard mismatches frozen plan')
    code=prepared_code()
    if sha((ROOT/'algorithms/makespan/dsla.cpp').read_bytes()) !=SRC_SHA:
        raise ValueError('Original DSLA source is not the pinned published benchmark commit')
    # Git object identity preserved from the archived original comparison engine.
    actual=subprocess.check_output(['git','hash-object',STUDY/'code/engine.cpp'],text=True).strip()
    if actual!=ENGINE_SHA:raise ValueError('Independent engine source Git blob SHA1 mismatch')
    bindir=WORK/'wf-bin';bindir.mkdir(exist_ok=True)
    check(['g++','-std=c++17','-O2',ROOT/'algorithms/makespan/dsla.cpp','-o',bindir/'dsla'])
    check(['g++','-std=c++17','-O2',STUDY/'code/engine.cpp','-o',bindir/'engine'])
    check([sys.executable,code/'holdout.py','--self-test'])
    folder=WORK/f'raw-study-shard-{a.shard}'
    folder.mkdir(parents=True,exist_ok=False)
    (folder/'partition.json').write_text(json.dumps(selection,indent=2)+'\n')
    (folder/'source_meta.json').write_text(json.dumps({'study_id':STUDY_ID,'source_sha256':SRC_SHA,'engine_git_blob':ENGINE_SHA,'public_repository':'alphanum545/scheduling-benchmark','source_tag':'v1.5','original_source_commit':'2f078d86b9d39835756f6ed9613279418a52371b'},indent=2)+'\n')
    child=folder/('holdout-'+fam)
    err=None
    try:
        if not selection['selected']:
            empty_result(child,fam)
        else:
            check([sys.executable,code/'holdout.py','--family',fam,'--wfinstances-root',WORK/'selected-wf',
                   '--original',bindir/'dsla','--engine',bindir/'engine','--out',child,'--timeout','90'])
    except Exception as e:
        err=e
        (folder/'EXECUTION_FAILURE.txt').write_text(traceback.format_exc())
    # Keep failed runs too: pack all per-shard raw output BEFORE signalling the error.
    buffer=io.BytesIO()
    with tarfile.open(fileobj=buffer,mode='w:gz') as tf:
        tf.add(folder,arcname='payload')
    raw=buffer.getvalue()
    out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('w',newline='') as f:
        writer=csv.writer(f)
        writer.writerow(['study','shard','family','part','payload_sha256','payload_base64'])
        writer.writerow([STUDY_ID,a.shard,fam,local,sha(raw),base64.b64encode(raw).decode('ascii')])
    print(f'Archived shard {a.shard}, family {fam}, compressed bytes {len(raw)}, output: {out}')
    if err:raise err
    return True

def unpack(raw:bytes,dst:Path):
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tf:
        for member in tf.getmembers():
            path=Path(member.name)
            if path.is_absolute() or '..' in path.parts or member.issym() or member.islnk():raise ValueError('Unsafe shard payload')
        tf.extractall(dst,filter='data')

def merge_study(argv):
    csv.field_size_limit(sys.maxsize)
    inputs=sorted(WORK.glob('shard-*.csv'))
    if not inputs:return False
    # This special branch is intended only for fixed study mode. Reject stale partial data.
    if len(inputs)!=N_SHARDS:raise RuntimeError(f'Expected exactly twenty public study shards, got {len(inputs)}')
    metadata={};dest=WORK/'wf_unpack';dest.mkdir(exist_ok=False)
    for path in inputs:
        with path.open(newline='') as f:
            reader=csv.DictReader(f);rows=list(reader)
        if len(rows)!=1 or rows[0]['study']!=STUDY_ID:
            raise RuntimeError('Malformed or non-study shard: '+str(path))
        row=rows[0];idx=int(row['shard']);fam,local=entry(idx)
        if (fam,int(row['part']))!=(row['family'],local):raise RuntimeError('Shard family mismatch')
        if idx in metadata:raise RuntimeError('Duplicate fixed shard')
        raw=base64.b64decode(row['payload_base64'],validate=True)
        if sha(raw)!=row['payload_sha256']:raise RuntimeError('SHA-256 mismatch for '+str(path))
        out=dest/str(idx);out.mkdir()
        unpack(raw,out)
        p=out/'payload'
        selection=json.loads((p/'partition.json').read_text())
        if selection.get('study_id')!=STUDY_ID or selection['family']!=fam or selection['local_shard']!=local:
            raise RuntimeError('Partition metadata mismatch')
        if (p/'EXECUTION_FAILURE.txt').exists():raise RuntimeError('One worker failed: '+(p/'EXECUTION_FAILURE.txt').read_text()[:500])
        metadata[idx]=selection
    if set(metadata)!=set(range(N_SHARDS)):raise RuntimeError('Missing shard IDs')
    outroot=WORK/'wf_merged';outroot.mkdir(exist_ok=False)
    coverage={}
    for family in FAMILIES:
        shards=[i for i in range(N_SHARDS) if entry(i)[0]==family]
        shas={metadata[i]['source_sha'] for i in shards}
        file_lists={tuple(metadata[i]['all_candidates']) for i in shards}
        if len(shas)!=1 or len(file_lists)!=1:raise RuntimeError('Disagreeing source tag or candidate enumeration')
        full=set(next(iter(file_lists)))
        selected=[(entry(i)[1], item['filename'],item['sha256']) for i in shards for item in metadata[i]['selected']]
        if set(name for _,name,_ in selected)!=full or len(selected)!=len(full):
            raise RuntimeError('Incomplete source coverage or duplicates in '+family)
        if any((metadata[shards[0]]['all_candidates'].index(name)%SHARDS_PER_FAMILY)!=local for local,name,_ in selected):
            raise RuntimeError('Partition deviates from frozen selection algorithm')
        folder=outroot/('holdout-'+family);folder.mkdir()
        manifests=[];failures=[];summaries=[]
        csvheader=None
        with gzip.open(folder/'results.csv.gz','wt',newline='') as csvout, gzip.open(folder/'raw_schedules.jsonl.gz','wb') as schedulesout:
            for i in shards:
                src=dest/str(i)/'payload'/('holdout-'+family)
                summ=json.loads((src/'summary.json').read_text());summaries.append(summ)
                manifests+=json.loads((src/'source_manifest.json').read_text())
                failures+=json.loads((src/'failures.json').read_text())
                with gzip.open(src/'results.csv.gz','rt',newline='') as cf:
                    header=cf.readline()
                    if csvheader is None:csvheader=header;csvout.write(header)
                    elif csvheader!=header:raise RuntimeError('CSV header mismatch')
                    shutil.copyfileobj(cf,csvout)
                with gzip.open(src/'raw_schedules.jsonl.gz','rb') as gf:shutil.copyfileobj(gf,schedulesout)
        if len(manifests)!=len(full) or {x['file'] for x in manifests}!=full:
            raise RuntimeError('Unmatched source files in merged manifest for '+family)
        info={'family':family,'source_files_found':len(full),'eligible':sum(q['eligible'] for q in summaries),
              'excluded':sum(q['excluded'] for q in summaries),'cases':sum(q['cases'] for q in summaries),
              'schedule_records':sum(q['schedule_records'] for q in summaries),'fatal_cases':sum(q['fatal_cases'] for q in summaries),
              'source_commit':'2f078d86b9d39835756f6ed9613279418a52371b','source_sha256':SRC_SHA,
              'wfinstances_sha':next(iter(shas)),'shards':len(shards)}
        (folder/'summary.json').write_text(json.dumps(info,indent=2)+'\n')
        (folder/'source_manifest.json').write_text(json.dumps(manifests,indent=2)+'\n')
        (folder/'failures.json').write_text(json.dumps(failures,indent=2)+'\n')
        if failures or info['fatal_cases']:
            raise RuntimeError('Scheduler failures detected; no silent deletion of cases')
        if info['cases']!=10*info['eligible'] or info['schedule_records']!=7*info['cases']:
            raise RuntimeError('Modeled cases/schedule coverage mismatch in '+family)
        coverage[family]=info
    (WORK/'wf_coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')
    (WORK/'wf_mode.flag').write_text(STUDY_ID+'\n')
    print('Verified all twenty source partitions and seven complete schedule results for every ten-mode eligible trace')
    return True

def report_study(argv):
    if '--algos' not in argv:return False
    if argv[argv.index('--algos')+1]!=SIGNAL:return False
    if '--name' not in argv:raise ValueError('Missing output report name')
    name=argv[argv.index('--name')+1]
    if not name.startswith('dsla_wfv15_') or not name.replace('_','').isalnum():
        raise ValueError('Report destination must be study-specific and safe')
    if (WORK/'wf_mode.flag').read_text().strip()!=STUDY_ID:raise RuntimeError('Missing verified twenty-way merge flag')
    code=prepared_code();sys.path.insert(0,str(code))
    from analyze_holdout import analyze
    destination=ROOT/'results/reports'/name
    if destination.exists():raise RuntimeError('Refusing to overwrite any existing report '+name)
    summary=analyze(WORK/'wf_merged',destination)
    shutil.copy2(WORK/'wf_coverage.json',destination/'SHARD_COVERAGE.json')
    shutil.copy2(destination/'HOLDOUT_REPORT.md',destination/'summary.md')
    (destination/'SOURCE_AND_LIMITATIONS.md').write_text('Public benchmark 20-shard WfInstances v1.5, source-frozen original DSLA and independent controls.\n'
       'Real recorded application DAG/task runtimes; deterministic MODELLED heterogeneous processor and communication costs, not measured cloud deployment.\n'
       'The authors of published baseline methods have not certified the insertion-based reimplementations.\n'
       'Every input eligible under the precommitted protocol was included; a failed case invalidates the run.\n'
       'Raw complete schedules remain in the twenty named Actions shard-*.csv artifacts (CSV with SHA256-verified base64 gzip bundle), in this same public repository.\n')
    # Keep raw shard artifacts when within responsible repository size bounds.
    inputs=list(WORK.glob('shard-*.csv'));total=sum(f.stat().st_size for f in inputs)
    if total<=50_000_000:
        raw=destination/'raw-shards';raw.mkdir()
        for item in inputs:shutil.copy2(item,raw/item.name)
    else:
        (destination/'RAW_ARTIFACTS_NOTICE.txt').write_text(f'{total} bytes of raw shard evidence exceeds the 50MB Git-history guard. All twenty original shards remain attached to this Actions run and must be archived promptly.\n')
    print('External WfInstances modelled-scheduling analysis complete. Reports:',destination)
    return True
